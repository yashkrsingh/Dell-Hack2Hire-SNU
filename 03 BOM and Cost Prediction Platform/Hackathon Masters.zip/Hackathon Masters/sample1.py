from flask import Flask,render_template,json,jsonify,request
import os
from model import machinel


app = Flask(__name__)

@app.route("/", methods=['GET','POST'])
def home():
    tabledata={}
    if request.method=='POST':
        data = request.form
        #call the model fn with data
        tabledata  = machinel(float(data['budget']),data['purpose'])
        tabledata['flag'] = False
        
    elif request.method=='GET':
        #populate the table with empty data
        tabledata = {
            'flag':True,
            'config1':[0,0,0,0,0,0],
        'config2':[0,0,0,0,0,0],
        'config3':[0,0,0,0,0,0],
        'config4':[0,0,0,0,0,0]
            
        }
    print(tabledata)
    return render_template('home.html',tabledata = tabledata)

if __name__ == "__main__":
    
    app.run(debug = True)

