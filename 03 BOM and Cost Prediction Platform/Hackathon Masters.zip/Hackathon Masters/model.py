import numpy as np
import pandas as pd
from sklearn import preprocessing
from sklearn.cluster import KMeans
from sklearn.neighbors import NearestNeighbors
from matplotlib import pyplot as plt

def initialize(items):
    minTotal = 0
    maxTotal = 0
    for item in items:
        item_price = item['Price']
        minP_item = min(item_price)
        maxP_item = max(item_price)
        minTotal += minP_item
        maxTotal += maxP_item
    return minTotal,maxTotal

def normalize(items):
    min_max_scaler = preprocessing.MinMaxScaler()
    norm_items = []
    for item in items:
        item_array1 = list(item[['Supplier Performance']].values.astype(float))
        item_array2 = list(item[['Commodity Performance']].values.astype(float))
        item_array3 = list(item[['Price']].values.astype(float))

        normalized_item1 = list(min_max_scaler.fit_transform(item_array1))
        normalized_item2 = list(min_max_scaler.fit_transform(item_array2))
        normalized_item3 = list(min_max_scaler.fit_transform(item_array3))

        item_norm = {'Supplier ID': [i for i in range(0, 2000)], 'Supplier Performance': normalized_item1,
                     'Commodity Performance': normalized_item2, 'Price': normalized_item3}
        normalised_item = pd.DataFrame(item_norm)
        norm_items.append(normalised_item)
    return norm_items

def computeResults(items,BudgetItem):
    result = []
    for j in range(len(items)):
        Test = pd.DataFrame(columns=['Supplier ID', 'Supplier Performance', 'Commodity Performance', 'Price'])
        Train = pd.DataFrame(columns=['Supplier ID', 'Supplier Performance', 'Commodity Performance', 'Price'])
        for i in range(len(items[j])):
            if items[j]['Price'][i] <= BudgetItem[j]:
                Test = Test.append(items[j].iloc[i, :])
            else:
                Train = Train.append(items[j].iloc[i, :])

        Test = Test.drop(['Supplier ID'], axis=1)
        Train = Train.drop(['Supplier ID'], axis=1)

        y_min = min(Test['Price'])
        centroid = (np.array(Test['Supplier Performance']) + np.array(Test['Commodity Performance'])) / 2
        Test['Mean Score'] = list(centroid)
        Test = Test.drop(['Supplier Performance', 'Commodity Performance'], axis=1)
        clusterCentroid = np.array([[y_min, max(centroid)], [y_min, min(centroid)]]).reshape(2, 2)
        res = computeKMeans(clusterCentroid, Test)
        result.append(res)
    return result

def computeKMeans(centroid, Test):
    kmeans = KMeans(n_clusters=2, init=centroid, max_iter=300, n_init=10)
    kmeans.fit(Test)
    #thispne
    #plt.scatter(Test['Price'], Test['Mean Score'])
    #plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], s=300, c='red')
    #plt.show()
    neigh = NearestNeighbors(4,0.4).fit(Test)
    return neigh.kneighbors(centroid,return_distance=True)

def machinel(budget,purpose):
        
    keyboard_file = pd.read_csv('E:\Studies\WebDev\dell\Keyboard Data.csv')
    hdd_file = pd.read_csv('E:\Studies\WebDev\dell\HDD Data.csv')
    screen_file = pd.read_csv('E:\Studies\WebDev\dell\Screen Data.csv')
    cpu_file = pd.read_csv('E:\Studies\WebDev\dell\CPU Data.csv')
    gpu_file = pd.read_csv('E:\Studies\WebDev\dell\GPU Data.csv')
    mouse_file = pd.read_csv('E:\Studies\WebDev\dell\Mouse Data.csv')

    keyboardData = pd.DataFrame(keyboard_file)
    mouseData = pd.DataFrame(mouse_file)
    hddData = pd.DataFrame(hdd_file)
    screenData = pd.DataFrame(screen_file)
    cpuData = pd.DataFrame(cpu_file)
    gpuData = pd.DataFrame(gpu_file)
    
    dataItems = [keyboardData, mouseData, hddData, screenData, cpuData, gpuData]
    norm_Items = normalize(dataItems)

    Budget = budget
    minTotal, maxTotal = initialize(dataItems)
    Remaining = (Budget - minTotal)/(maxTotal - minTotal)
    minItemPrice = np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0])

    keyboard_price = keyboardData['Price']
    minP_keyboard = min(keyboard_price)
    maxP_keyboard = max(keyboard_price)

    mouse_price = mouseData['Price']
    maxP_mouse = max(mouse_price)
    minP_mouse = min(mouse_price)

    hdd_price = hddData['Price']
    minP_hdd = min(hdd_price)
    maxP_hdd = max(hdd_price)

    screen_price = screenData['Price']
    minP_screen = min(screen_price)
    maxP_screen = max(screen_price)

    cpu_price = cpuData['Price']
    minP_cpu = min(cpu_price)
    maxP_cpu = max(cpu_price)

    gpu_price = gpuData['Price']
    minP_gpu = min(gpu_price)
    maxP_gpu = max(gpu_price)

    Importance1 = np.array([0.05, 0.05, 0.1, 0.2, 0.3, 0.3])
    Importance2 = np.array([0.1, 0.1, 0.2, 0.25, 0.2, 0.15]) 
    Importance3 = np.array([0.05, 0.05, 0.2, 0.2, 0.25, 0.25])

    if purpose == "Gaming":
        BudgetItem = np.array(Remaining*Importance1) + minItemPrice
    elif purpose == "Business":
        BudgetItem = np.array(Remaining*Importance2) + minItemPrice
    else:
        BudgetItem = np.array(Remaining*Importance3) + minItemPrice

    #rangeItem = [(0.0, BudgetItem[0]), (0.0, BudgetItem[1]), (0.0, BudgetItem[2]),(0.0, BudgetItem[3]),(0.0,BudgetItem[4]),(0.0,BudgetItem[5])]

    result = computeResults(norm_Items,BudgetItem)

    config1 = [result[0][0][0][0]*(maxP_keyboard-minP_keyboard) + minP_keyboard,result[1][0][0][0]*(maxP_mouse-minP_mouse) + minP_mouse,result[2][0][0][0]*(maxP_hdd-minP_hdd) + minP_hdd, result[3][0][0][0]*(maxP_screen-minP_screen) + minP_screen, result[4][0][0][0]*(maxP_cpu-minP_cpu) + minP_cpu,result[5][0][0][0]*(maxP_gpu-minP_gpu) + minP_gpu]

    config2 = [result[0][0][0][1]*(maxP_keyboard-minP_keyboard) + minP_keyboard,result[1][0][0][1]*(maxP_mouse-minP_mouse) + minP_mouse,result[2][0][0][1]*(maxP_hdd-minP_hdd) + minP_hdd,result[3][0][0][1]*(maxP_screen-minP_screen) + minP_screen,result[4][0][0][1]*(maxP_cpu-minP_cpu) + minP_cpu,result[5][0][0][1]*(maxP_gpu-minP_gpu) + minP_gpu]

    config3 = [result[0][0][0][2]*(maxP_keyboard-minP_keyboard) + minP_keyboard,result[1][0][0][2]*(maxP_mouse-minP_mouse) + minP_mouse,result[2][0][0][2]*(maxP_hdd-minP_hdd) + minP_hdd,result[3][0][0][2]*(maxP_screen-minP_screen) + minP_screen,result[4][0][0][2]*(maxP_cpu-minP_cpu) + minP_cpu,result[5][0][0][2]*(maxP_gpu-minP_gpu) + minP_gpu]

    config4 = [result[0][0][0][3]*(maxP_keyboard-minP_keyboard) + minP_keyboard,result[1][0][0][3]*(maxP_mouse-minP_mouse) + minP_mouse,result[2][0][0][3]*(maxP_hdd-minP_hdd) + minP_hdd,result[3][0][0][3]*(maxP_screen-minP_screen) + minP_screen,result[4][0][0][3]*(maxP_cpu-minP_cpu) + minP_cpu, result[5][0][0][3]*(maxP_gpu-minP_gpu) + minP_gpu]

    dic = {'config1': config1,'config2': config2,'config3': config3,'config4': config4}
    return dic